var computerChoice = 0;
	var gameOutput = 0;
	function start() {
	computerChoice = Math.floor(Math.random()* 3); //comp choice r, p, s
	highlightComp();//highlights computers choice
	gameOutput = Math.floor(Math.random() * 3); //comp choice of win or lose
	gameOP(); //calls the gameOP to convert into meaning
	
	
	/////////Timer for 2 minutes
	var time_in_minutes = 2;
	var current_time = Date.parse(new Date());
	var deadline = new Date(current_time + time_in_minutes*60*1000);


	function time_remaining(endtime){
		var t = Date.parse(endtime) - Date.parse(new Date());
		var seconds = Math.floor( (t/1000) % 60 );
		var minutes = Math.floor( (t/1000/60) % 60 );
		return {'total':t, 'minutes':minutes, 'seconds':seconds};
	}
	function run_clock(id,endtime){
		var clock = document.getElementById(id);
		function update_clock(){
			var t = time_remaining(endtime);
			clock.innerHTML = 'Time: '+t.minutes+':'+t.seconds;
			if(t.total<=0){ clearInterval(timeinterval); alert("Time is up"); resetChoice(); resetWins(); }
		}
		update_clock(); // run function once at first to avoid delay
		var timeinterval = setInterval(update_clock,1000);
	}
	run_clock('clockdiv',deadline);
	///////Timer
	}
	
	
	//variables to highlight comp
	var redHigh1 = document.getElementById("rock1");
	var greenHigh1 = document.getElementById("paper1");
	var blueHigh1 = document.getElementById("scissors1");
	
	
	////highlights computers choice
	function highlightComp() {
	if (computerChoice == 0) {
        computerChoice = "rock";
		redHigh1.setAttribute("id", "changeRed");
		
    } else if (computerChoice == 1) {
        computerChoice = "paper";
		greenHigh1.setAttribute("id","changeGreen");
		
    } else {
        computerChoice = "scissors"; 
		blueHigh1.setAttribute("id", "changeBlue");
				
    }
	}
	
	

	
	var output = document.getElementById('gameOutput'); //displays in div
	
	//// converts game output to win, ties, or lose
	function gameOP() {
		
		if(gameOutput == 0) {
			gameOutput= "win";
			output.innerHTML = "Win the game.";
		}
		else if (gameOutput ==1) {
			gameOutput ="lose";
			output.innerHTML = "Lose the Game.";
		} else if (gameOutput ==2) {
			gameOutput ="tie";
			output.innerHTML = "Tie the Game.";
		}
	}
	
	
	
    var userChoice = null; //gotten when clicked on
	//variables for highlighting the user choice
	var redHigh = document.getElementById("rock");
	var greenHigh = document.getElementById("paper");
	var blueHigh = document.getElementById("scissors");

	//converts user click into meaning
	$("#rock").click(function() {
        convertUserChoice("rock");
    });
    $("#paper").click(function() {
        convertUserChoice("paper");
    });
    $("#scissors").click(function() {
        convertUserChoice("scissors");
    });
	
	
	////each of these highlights the users hands
	function highlightRed() {
	redHigh.setAttribute("id", "changeRed");
	}
	function highlightGreen() {
	greenHigh.setAttribute("id","changeGreen");
	}
	function highlightBlue() {
	blueHigh.setAttribute("id", "changeBlue");

	}
	var userScore=0; //score variable

	//displays the score
	function getScore() {
	document.getElementById("userScore").innerHTML = userScore;	
	}
	
	//resets the computers choice
	function resetChoice() {
	computerChoice = Math.floor(Math.random()* 3); //comp choice r, p, s
	highlightComp();//highlights computers choice
	gameOutput = Math.floor(Math.random() * 3); //comp choice of win or lose
	gameOP(); //calls the gameOP to convert into meaning
	}
	
	//resets the score and displays it
	function resetWins() {
		userScore = 0;
		output.innerHTML="";
		answer.innerHTML="";
		getScore();
		resetColor();
	}

	
	//
   function convertUserChoice(userChoice) {
   
		if(gameOutput == "win") {
		//call function to do work
			winWork(userChoice);
		} else if (gameOutput=="lose") {
		//call function to do work
			loseWork(userChoice);
		} else if (gameOutput=="tie") {
		//call function to do work
			tieWork(userChoice);
		}
		getScore();
		resetColor();
		resetChoice();
   }
   var answer = document.getElementById('answer');
   //does the work for gameOutput = win
	function winWork(userChoice) {
		if(userChoice == "rock" && computerChoice == "scissors") {
			//award points
			answer.innerHTML ="Rock wins over Scissors. +100 points.";
			userScore += 100;
		} else if (userChoice == "paper" && computerChoice == "rock") {
			//award points
			answer.innerHTML ="Paper wins over Rock. +100 points.";
			userScore += 100;
		} else if (userChoice == "scissors" && computerChoice == "paper") {
			//award points
			answer.innerHTML ="Scissors wins over Paper. +100 points.";
			userScore += 100;
		} else {
			//deduct points
			answer.innerHTML ="INCORRECT! -200 points";
			userScore -= 200;
		}
	
	}
	//does work for gameOutput = lose
	function loseWork(userChoice) {
		if(userChoice == "rock" && computerChoice == "paper") {
			//award points
			answer.innerHTML = "Rock loses over Paper. +100 points."
			userScore += 100;
		} else if (userChoice == "paper" && computerChoice == "scissors") {
			//award points
			answer.innerHTML ="Paper loses over Scissors. +100 points.";
			userScore += 100;
		} else if (userChoice == "scissors" && computerChoice == "rock") {
			//award points
			answer.innerHTML = "Scissors loses over Rock. +100 points.";
			userScore += 100;
		} else {
			//deduct points
			answer.innerHTML = "INCORRECT! -200 points";
			userScore -= 200;
		}
	}
	//does the work for gameOutput = tie
	function tieWork(userChoice) {
		if(userChoice == computerChoice) {
			//award points
			answer.innerHTML = "There was a tie! +100 points."
			userScore += 100;
		} else {
			//incorrect deduct points
			answer.innerHTML = "INCORRECT! -200 points";
			userScore -= 200;
		}
	
	}
		
	//resets all the colors to white	
	function resetColor() {
		redHigh.setAttribute("id","changeWhite");
		greenHigh.setAttribute("id", "changeWhite");
		blueHigh.setAttribute("id", "changeWhite");
		redHigh1.setAttribute("id","changeWhite");
		greenHigh1.setAttribute("id", "changeWhite");
		blueHigh1.setAttribute("id", "changeWhite");		
	
	}