var PlayerWins = 0;
var ComputerWins = 0; 
var Ties = 0; 
var Round = 1; 
var Credits = 100; 
var HighScore = 0; 
var Tied = false; 
var TiedCredits = 0;
var computerChoice;
var Rock1 = 3;
var Paper1 = 3;
var Scissors1 = 3;
var Result = document.getElementById("results");
var Start = document.getElementById("start");
var Rock = document.getElementById("rock");
var Paper = document.getElementById("paper");
var Scissors = document.getElementById("scissors");
var Winner = document.getElementById("winner");
var BetAmount = document.getElementById("betAmount");
var TiedComputer = document.getElementById("tiedComputer");

Result.style.visibility = "hidden";
TiedComputer.style.visibility = "hidden";
Start.addEventListener("click", startResetButton);
Rock.addEventListener("click", rockButton);
Paper.addEventListener("click", paperButton);
Scissors.addEventListener("click", scissorsButton);
BetAmount.addEventListener("keyup", maxInput);
Rock.disabled = true;
Paper.disabled = true;
Scissors.disabled = true;
BetAmount.disabled = true;

// Start/reset
function startResetButton() {
    Rock.disabled = false;
    Paper.disabled = false;
    Scissors.disabled = false;
    BetAmount.disabled = false;

    BetAmount.value = "";

    Result.style.visibility = "hidden";
    TiedComputer.style.visibility = "hidden";

    PlayerWins = 0;
    ComputerWins = 0;
    Ties = 0;
    Round = 1;
    Credits = 100;
    TiedCredits = 0;
    Tied = false;

    Rock1 = 3;
    Paper1 = 3;
    Scissors1 = 3;

    document.getElementById("playerWins").textContent = 'Player Wins: ' + PlayerWins;
    document.getElementById("computerWins").textContent = 'Computer Wins: ' + ComputerWins;
    document.getElementById("ties").textContent = 'Ties: ' + Ties;
    document.getElementById("credits").textContent = 'Your Credits: ' + Credits;
    document.getElementById("rounds").textContent = "Round: " + Round;
}
function maxInput() {
    if (!/^[0-9]+$/.test(BetAmount.value)) {
        BetAmount.value = "";
    }
    else if (BetAmount.value > Credits || BetAmount.value === "0") {
        BetAmount.value = null;
    }
}
function rockButton() {
    if (Tied === true) {
        if (BetAmount.value.length > 0 && parseInt(BetAmount.value) >= TiedCredits) {
            Rock.style.background = '#ff8';
            Paper.style.background = '';
            Scissors.style.background = '';
            computer("Rock");
        }
    }
    else if (BetAmount.value.length > 0) {
        Rock.style.background = '#ff8';
        Paper.style.background = '';
        Scissors.style.background = '';
        computer("Rock");
    }
}
function paperButton() {
    if (Tied === true) {
        if (BetAmount.value.length > 0 && parseInt(BetAmount.value) >= TiedCredits) {
            Rock.style.background = '';
            Paper.style.background = '#ff8';
            Scissors.style.background = '';
            computer("Paper");
        }
    }
    else if (BetAmount.value.length > 0) {
        Rock.style.background = '';
        Paper.style.background = '#ff8';
        Scissors.style.background = '';
        computer("Paper");
    }
}
function scissorsButton() {
    if (Tied === true) {
        if (BetAmount.value.length > 0 && parseInt(BetAmount.value) >= TiedCredits) {
            Rock.style.background = '';
            Paper.style.background = '';
            Scissors.style.background = '#ffff88';
            computer("Scissors");
        }
    }
    else if (BetAmount.value.length > 0) {
        Rock.style.background = '';
        Paper.style.background = '';
        Scissors.style.background = '#ffff88';
        computer("Scissors");
    }

}
function computer(playerChoice) {
    var selected = false;
    do {
        var number = Math.floor(Math.random() * 3);

        if (number === 0 && Rock1 !== 0) {
            computerChoice = "Rock";
            Rock1--;
            selected = true;
        }
        else if (number === 1 && Paper1 !== 0) {
            computerChoice = "Paper";
            Paper1--;
            selected = true;
        }
        else if (number === 2 && Scissors1 !== 0) {
            computerChoice = "Scissors";
            Scissors1--;
            selected = true;
        }
    } while (selected === false);

    document.getElementById("comPick").textContent = 'Computer choose: ' + computerChoice;
    results(playerChoice, computerChoice)
}

function results(playerChoice, computerChoice) {
    if (playerChoice === computerChoice) {
        Winner.textContent = 'Player ties with Computer';
        Ties++;
        Tied = true;
        TiedCredits = parseInt(BetAmount.value * 2);
        TiedComputer.textContent = 'You tied the computer last round. Bet Double. Min Bet =  ' + parseInt(TiedCredits) + '.';
        TiedComputer.style.visibility = "visible";
    }
    else if (playerChoice === "Rock" && computerChoice === "Scissors") {
        Winner.textContent = 'Rock beats Scissors. Player Wins';
        PlayerWins++;
        TiedCredits = 0;
        Credits = parseInt(Credits) + parseInt(BetAmount.value);
        TiedComputer.style.visibility = "hidden";
    }
    else if (playerChoice === "Paper" && computerChoice === "Rock") {
        Winner.textContent = 'Paper beats Rock. Player Wins';
        PlayerWins++;
        TiedCredits = 0;
        Credits = parseInt(Credits) + parseInt(BetAmount.value);
        TiedComputer.style.visibility = "hidden";
    }
    else if (playerChoice === "Scissors" && computerChoice === "Paper") {
        Winner.textContent = 'Scissors beats Paper. Player Wins';
        PlayerWins++;
        TiedCredits = 0;
        Credits = parseInt(Credits) + parseInt(BetAmount.value);
        TiedComputer.style.visibility = "hidden";
    }
    else {
        Winner.textContent = computerChoice + ' beats ' + playerChoice + '. Computer Wins';
        ComputerWins++;
        TiedCredits = 0;
        Credits = parseInt(Credits) - parseInt(BetAmount.value);
        TiedComputer.style.visibility = "hidden";
    }
    results.style.visibility = "visible";
    document.getElementById("playerWins").textContent = 'Player Wins: ' + PlayerWins;
    document.getElementById("computerWins").textContent = 'Computer Wins: ' + ComputerWins;
    document.getElementById("ties").textContent = 'Ties: ' + Ties;
    document.getElementById("credits").textContent = 'Your Credits: ' + Credits;
    if (parseInt(Credits) <= 0 || parseInt(Credits) < parseInt(TiedCredits)) {
        Rock.style.background = '';
        Paper.style.background = '';
        Scissors.style.background = '';
        BetAmount.value = null;
        Rock.disabled = true;
        Paper.disabled = true;
        Scissors.disabled = true;
        BetAmount.disabled = true;

        if (parseInt(Credits) < parseInt(TiedCredits)) {
            TiedComputer.textContent = 'You tied the computer last round. Bet Double. Min Bet = ' + parseInt(TiedCredits)
                + '\r\nNot enough credits to bet. Click start to try again.';
            TiedComputer.style.visibility = "visible";
        }
        else {
            TiedComputer.textContent = 'You went Bankrupt. Click start to try again.';
            TiedComputer.style.visibility = "visible";
        }
    }
    else if (Round < 9) {
        Round = Round + 1;
        BetAmount.value = null;
        document.getElementById("rounds").textContent = "Round: " + Round;

    }
    else {
        Rock.style.background = '';
        Paper.style.background = '';
        Scissors.style.background = '';
        BetAmount.value = null;
        Rock.disabled = true;
        Paper.disabled = true;
        Scissors.disabled = true;
        BetAmount.disabled = true;

        if (parseInt(HighScore) < parseInt(Credits)) {
            HighScore = Credits;
            document.getElementById("highScore").textContent = 'High Score: ' + Credits;
        }
    }
}