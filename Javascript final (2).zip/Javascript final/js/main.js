 var computerChoice = Math.floor(Math.random()* 3);
    var userChoice = null;
	
	var computerWin = 0;
	var userWin=0;
	var blueHigh1 = document.getElementById("scissors1");
	var redHigh = document.getElementById("rock");
	var greenHigh = document.getElementById("paper");
	var blueHigh = document.getElementById("scissors");
	var redHigh1 = document.getElementById("rock1");
	var greenHigh1 = document.getElementById("paper1");
	    $("#rock").click(function() {
            convertUserChoice("rock");
        });
        $("#paper").click(function() {
            convertUserChoice("paper");
        });
        $("#scissors").click(function() {
            convertUserChoice("scissors");
        });
	
	function highlightRed() {
	//var redHigh = document.getElementById("rock");
	redHigh.setAttribute("id", "changeRed");
	//document.getElementById("rock").style.background ="#FF0000";
	highlightComp();
	}
	function highlightGreen() {
	//var greenHigh = document.getElementById("paper");
	greenHigh.setAttribute("id","changeGreen");
	//document.getElementById("paper").style.background ="#008000";
	highlightComp();
	}
	function highlightBlue() {
	//var blueHigh = document.getElementById("scissors");
	blueHigh.setAttribute("id", "changeBlue");
	//document.getElementById("scissors").style.background ="#0000ff";
	highlightComp();

	}

	function highlightComp() {
	if (computerChoice == 0) {
        computerChoice = "rock";
		//var redHigh1 = document.getElementById("rock1");
		redHigh1.setAttribute("id", "changeRed");
		//document.getElementById("rock1").style.backgroundColor="#FF0000";
    } else if (computerChoice == 1) {
        computerChoice = "paper";
		//var greenHigh1 = document.getElementById("paper1");
		greenHigh1.setAttribute("id","changeGreen");
		//document.getElementById("paper1").style.backgroundColor="#008000";
    } else {
        computerChoice = "scissors"; 
		//var blueHigh1 = document.getElementById("scissors1");
		blueHigh1.setAttribute("id", "changeBlue");
		//document.getElementById("scissors1").style.backgroundColor="#0000ff";		
    }
	}


	function getScore() {
	document.getElementById("userScore").innerHTML = userWin;
	document.getElementById("computerScore").innerHTML = computerWin;
	
		if(userWin >= 1 || computerWin >=1) {
			resetChoice();
		}
	
		if(userWin >= 3|| computerWin>=3) {
			alert("Game over");
			if(userWin > computerWin){
				alert("User wins.");
				
			} else if( computerWin > userWin) {
				alert("Computer wins.");
			} else {
				alert("Tie.");
			}
			resetWins();
		}
		
	}

	function resetChoice() {
	computerChoice = Math.floor(Math.random()* 3);
	}
	function resetWins() {
		userWin = 0;
		computerWin=0;
		getScore();
	}

   function convertUserChoice(userChoice) {
   if (userChoice == computerChoice) {
        alert ("Tie!");
		resetColor();
		getScore();
    } else if (userChoice == "rock") {
        if (computerChoice == "scissors") {
            alert ("You win! The computer picked scissors.");
			userWin++;
			getScore();
        } else {
			alert("You lose. The computer picked paper")
			computerWin++;
			getScore();
        }
		resetColor();
    } else if (userChoice == "paper") {
        if (computerChoice == "rock") {
            alert ("You win! The computer picked rock.");
			userWin++;
			getScore();
        } else {
            alert("You lose. The computer picked scissors.");
			computerWin++;
			getScore();
        }
		resetColor();
    } else if (userChoice == "scissors") {
        if (computerChoice == "paper") {
            alert ("You win! The computer picked paper.");
			userWin++;
			getScore();
        } else {
            alert("You lose. The computer picked Rock.");
			computerWin++;
			getScore();
        }
		resetColor();
    }
     
    }


		
		
	function resetColor() {
		redHigh.setAttribute("id","changeWhite");
		greenHigh.setAttribute("id", "changeWhite");
		blueHigh.setAttribute("id", "changeWhite");
		redHigh1.setAttribute("id","changeWhite");
		greenHigh1.setAttribute("id", "changeWhite");
		blueHigh1.setAttribute("id", "changeWhite");		
		/*
		document.getElementById("rock").style.background="#ffffff";
		document.getElementById("paper").style.background="#ffffff";
		document.getElementById("scissors").style.background="#ffffff";
		document.getElementById("rock1").style.backgroundColor="#ffffff";
		document.getElementById("paper1").style.backgroundColor="#ffffff";
		document.getElementById("scissors1").style.backgroundColor="#ffffff";*/
	
	}