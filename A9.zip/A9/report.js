/*

   Author:   Rachel Laub
   Date:     3/28/18

   Filename: report.js



   Functions List:

   initPage()
      Initializes the contents of the Web page

   testLength()
      Tests a field for its length

   testPattern()
      Tests a field for its pattern

   validateForm
      Validates a Web form

   calcRow
      Calculates the costs within one row of the travel report

   calcTotal
      Calculates the total cost of the travel

   upDate
      Updates the total travel cost
*/
window.onload = initPage;
function initPage() {	
	var dataFields = new Array();
	var elements = document.getElementsByTagName("*");
	for (var i = 0; i < elements.length ; i++) {
		if (elements.className == "expenseEntry") {
			dataFields.push(elements);
		}
	}
	for (var i = 0; i < dataFields.length; i++) {
		dataFields.onblur = update;
	}

document.expform = validateForm; //needs help
	
}

function testLength(field) {
   if (field.value.length == 0) {
		field.style.backgroundColor="yellow";
		return false;
   }
   else {
		field.style.backgroundColor="white";
		return true;
   }
}
function testPattern(field, reg) { 
   if (reg.test(field.value)== false) { 
		field.style.backgroundColor="yellow";  
		field.style.color="red";
		return false;
   }
   else {
		field.style.backgroundColor="white";  
		field.style.color="black";
		return true;
   }
}
 
 
function validateForm() {  
   var valid = true;
   
   if (testLength(document.expform[0].lname)==false) {  
		valid = false;
   }
   else if (testLength(document.expform[0].fname)==false) { 
		valid = false;
   }
   else if (testLength(document.expform[0].address)==false) {
		valid = false;
   }
   else if (testLength(document.expform[0].summary)==false) {
		valid = false;
   }
   if (testPattern(document.expform[0].account,/^ACT\d{6}$/)==false) {  
		valid = false;
   }
   if (testPattern(document.expform[0].department,/^DEPT\d{3}$/)==false) {
		valid = false;
   }
   if (testPattern(document.expform[0].project,/^PROJ\d{5}$/)==false) {  
		valid = false;
   }
   if (testPattern(document.expform[0].ssn,/^\d{9}|\d{3}-\d{2}-\d{4}$/)==false) {
		valid = false;
   }
   if (valid == false) {
		alert("Please fill out all required fields in the proper format.");
   }
   return valid;
}
 
function calcRow(row) {
   var travel = parseFloat(document.expform[0].elements["travel"+row].value); 
   var lodge = parseFloat(document.expform[0].elements["lodge"+row].value);  
   var meal = parseFloat(document.expform[0].elements["meal"+row].value); 
   
   return (travel + lodge + meal); 
}
 
function calcTotal() {  
   var totalexp = 0;
   for (i=1;i<=4;i++) {
   totalexp += calcRow(i);
   }
   return totalexp;  
}
 
function update(expense) {  
   var numRegExp = /^\d*(\.\d{0,2})?$/;
   if (numRegExp.test(expense)!==false) {
		(expense.value).toFixed(2);
		for (i=1;i<=4;i++) {
			document.expform[0].elements["sub"+i].value=calcRow(i).toFixed(2);
			document.expform[0].total.value=calcTotal().toFixed(2);
		}
   } 
   else {
   alert("Invalid currency value"); 
   (expense.value = "0.00");
   expense.focus();
   }
}